﻿using System;
using ShopBridge.API.Models;

namespace ShopBridge.API.UnitTests
{
    public static class DbContextExtensions
    {
        public static void Seed(this InventoryDbContext dbContext)
        {
            // Add entities for DbContext instance

            dbContext.InventoryItems.Add(new InventoryItem
            {
                InventoryItemID = 1,
                InventoryItemName = "Laptop",
                SupplierID = 12,               
                TaxRate = 15.000m,
                Price = 25.00m,               
                ValidFrom = new DateTime(2021, 5, 31, 23, 11, 0),
                ValidTo = new DateTime(9999, 12, 31, 23, 59, 59)
            });

            dbContext.InventoryItems.Add(new InventoryItem
            {
                InventoryItemID = 2,
                InventoryItemName = "HardDisk",
                SupplierID = 12,               
                TaxRate = 15.000m,
                Price = 25.00m,
                ValidFrom = new DateTime(2021, 5, 31, 23, 11, 0),
                ValidTo = new DateTime(9999, 12, 31, 23, 59, 59)
            });

            dbContext.InventoryItems.Add(new InventoryItem
            {
                InventoryItemID = 3,
                InventoryItemName = "Monitor",
                SupplierID = 12,              
                TaxRate = 15.000m,
                Price = 18.50m,
                ValidFrom = new DateTime(2021, 5, 31, 23, 11, 0),
                ValidTo = new DateTime(9999, 12, 31, 23, 59, 59)
            });

            dbContext.InventoryItems.Add(new InventoryItem
            {
                InventoryItemID = 4,
                InventoryItemName = "Speakers",
                SupplierID = 12,              
                TaxRate = 15.000m,
                Price = 32.00m,
                ValidFrom = new DateTime(2021, 5, 31, 23, 11, 0),
                ValidTo = new DateTime(9999, 12, 31, 23, 59, 59)
            });

            dbContext.InventoryItems.Add(new InventoryItem
            {
                InventoryItemID = 5,
                InventoryItemName = "Printer",
                SupplierID = 12,                
                TaxRate = 15.000m,
                Price = 32.00m,
                ValidFrom = new DateTime(2021, 5, 31, 23, 11, 0),
                ValidTo = new DateTime(9999, 12, 31, 23, 59, 59)
            });

            dbContext.InventoryItems.Add(new InventoryItem
            {
                InventoryItemID = 6,
                InventoryItemName = "USB Flash drive",
                SupplierID = 12,               
                TaxRate = 15.000m,
                Price = 32.00m,                
                ValidFrom = new DateTime(2021, 5, 31, 23, 11, 0),
                ValidTo = new DateTime(9999, 12, 31, 23, 59, 59)
            });

            dbContext.InventoryItems.Add(new InventoryItem
            {
                InventoryItemID = 7,
                InventoryItemName = "CD",
                SupplierID = 12,
                TaxRate = 15.000m,
                Price = 32.00m,                
                ValidFrom = new DateTime(2021, 5, 31, 23, 11, 0),
                ValidTo = new DateTime(9999, 12, 31, 23, 59, 59)
            });

           

           

          

            dbContext.SaveChanges();
        }
    }
}
