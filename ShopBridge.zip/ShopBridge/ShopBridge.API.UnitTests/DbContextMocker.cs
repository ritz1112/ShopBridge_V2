﻿using Microsoft.EntityFrameworkCore;
using ShopBridge.API.Models;

namespace ShopBridge.API.UnitTests
{
    public static class DbContextMocker
    {
        public static InventoryDbContext GetShopBridgeDbContext(string dbName)
        {
            // Create options for DbContext instance
            var options = new DbContextOptionsBuilder<InventoryDbContext>()
                .UseInMemoryDatabase(databaseName: dbName)
                .Options;

            // Create instance of DbContext
            var dbContext = new InventoryDbContext(options);

            // Add entities in memory
            dbContext.Seed();

            return dbContext;
        }
    }
}
