using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using ShopBridge.API.Controllers;
using ShopBridge.API.Models;
using Xunit;

namespace ShopBridge.API.UnitTests
{
    public class ShopridgeControllerUnitTest
    {
        [Fact]
        public async Task TestGetInventoryItemsAsync()
        {
            // Arrange
            var dbContext = DbContextMocker.GetShopBridgeDbContext(nameof(TestGetInventoryItemsAsync));
            var controller = new InventoryController(null, dbContext);

            // Act
            var response = await controller.GetInventoryItemsAsync() as ObjectResult;
            var value = response.Value as IPagedResponse<InventoryItem>;

            dbContext.Dispose();

            // Assert
            Assert.False(value.IsError);
        }

        [Fact]
        public async Task TestGetInventoryItemAsync()
        {
            // Arrange
            var dbContext = DbContextMocker.GetShopBridgeDbContext(nameof(TestGetInventoryItemAsync));
            var controller = new InventoryController(null, dbContext);
            var id = 1;

            // Act
            var response = await controller.GetInventoryItemAsync(id) as ObjectResult;
            var value = response.Value as ISingleResponse<InventoryItem>;

            dbContext.Dispose();

            // Assert
            Assert.False(value.IsError);
        }

        [Fact]
        public async Task TestAddInventoryItemAsync()
        {
            // Arrange
            var dbContext = DbContextMocker.GetShopBridgeDbContext(nameof(TestAddInventoryItemAsync));
            var controller = new InventoryController(null, dbContext);
            var request = new PostInventoryItemsRequest
            {
                InventoryItemID = 100,
                InventoryItemName = "Headphone",
                SupplierID = 12,               
                TaxRate = 15.000m,
                Price = 32.00m,  
                ValidFrom = DateTime.Now,
                ValidTo = DateTime.Now.AddYears(5)
            };

            // Act
            var response = await controller.AddInventoryItemAsync(request) as ObjectResult;
            var value = response.Value as ISingleResponse<InventoryItem>;

            dbContext.Dispose();

            // Assert
            Assert.False(value.IsError);
        }

        [Fact]
        public async Task TestUpdateInventoryItemAsync()
        {
            // Arrange
            var dbContext = DbContextMocker.GetShopBridgeDbContext(nameof(TestUpdateInventoryItemAsync));
            var controller = new InventoryController(null, dbContext);
            var id = 12;
            var request = new PutInventoryItemsRequest
            {
                InventoryItemName = "Speakers",
                SupplierID = 12,
                ColorID = 3
            };

            // Act
            var response = await controller.UpdateInventoryItemAsync(id, request) as ObjectResult;
            var value = response.Value as IResponse;

            dbContext.Dispose();

            // Assert
            Assert.False(value.IsError);
        }

        [Fact()]
        public async Task TestDeleteInventoryItemAsync()
        {
            // Arrange
            var dbContext = DbContextMocker.GetShopBridgeDbContext(nameof(TestDeleteInventoryItemAsync));
            var controller = new InventoryController(null, dbContext);
            var id = 5;

            // Act
            var response = await controller.DeleteInventoryItemAsync(id) as ObjectResult;
            var value = response.Value as IResponse;

            dbContext.Dispose();

            // Assert
            Assert.False(value.IsError);
        }
    }
}
