﻿using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using ShopBridge.API.Models;

namespace ShopBridge.API.Controllers
{
#pragma warning disable CS1591
    [ApiController]
    [Route("api/v1/[controller]")]
    public class InventoryController : ControllerBase
    {
        protected readonly ILogger Logger;
        protected readonly InventoryDbContext DbContext;

        public InventoryController(ILogger<InventoryController> logger, InventoryDbContext dbContext)
        {
            Logger = logger;
            DbContext = dbContext;
        }

        // GET
        // api/v1/ShopBridge/InventoryItem

        /// <summary>
        /// Retrieves Inventory items
        /// </summary>
        /// <returns>A response with Inventory items list</returns>
        [HttpGet("InventoryItem")]       
        public async Task<IActionResult> GetInventoryItemsAsync()
        {
            Logger.LogDebug("'{0}' has been invoked", nameof(GetInventoryItemsAsync));

            var response = new ListResponse<InventoryItem>();
            try
            {
                // Get the "proposed" query from repository
                var query = DbContext.GetInventoryItems();
                
                // Get the specific page from database
                response.Model = await query.ToListAsync();

                response.Message = string.Format("Total Iteme retreived", response.ItemsCount);

                Logger.LogInformation("The Inventory items have been successfully retrieved.");
            }
            catch (Exception ex)
            {
                response.IsError = true;
                response.ErrorMessage = "There was an internal error, please contact to technical support.";
                Logger.LogCritical("There was an error on '{0}' invocation: {1}", nameof(GetInventoryItemsAsync), ex);
            }

            return response.ToHttpResponse();
        }

        // GET
        // api/v1/ShopBridge/InventoryItem/5

        /// <summary>
        /// Retrieves a Inventory item by ID
        /// </summary>
        /// <param name="id">Inventory item id</param>
        /// <returns>A response with Inventory item</returns>       
        [HttpGet("InventoryItem/{id}")]       
        public async Task<IActionResult> GetInventoryItemAsync(int id)
        {
            Logger.LogDebug("'{0}' has been invoked", nameof(GetInventoryItemAsync));

            var response = new SingleResponse<InventoryItem>();

            try
            {
                // Get the Inventory item by id
                response.Model = await DbContext.GetInventoryItemsAsync(new InventoryItem(id));
            }
            catch (Exception ex)
            {
                response.IsError = true;
                response.ErrorMessage = "There was an internal error, please contact to technical support.";
                Logger.LogCritical("There was an error on '{0}' invocation: {1}", nameof(GetInventoryItemAsync), ex);
            }

            return response.ToHttpResponse();
        }

        // POST
        // api/v1/ShopBridge/InventoryItem/

        /// <summary>
        /// Creates a new Inventory item
        /// </summary>
        /// <param name="request">Request model</param>
        /// <returns>A response with new Inventory item</returns>
        /// <response code="201">A response as creation of Inventory item</response>
        /// <response code="400">For bad request</response>
        /// <response code="500">If there was an internal server error</response>
        [HttpPost("InventoryItem")]       
        public async Task<IActionResult> AddInventoryItemAsync([FromBody]PostInventoryItemsRequest request)
        {
            Logger.LogDebug("'{0}' has been invoked", nameof(AddInventoryItemAsync));

            var response = new SingleResponse<InventoryItem>();

            try
            {
                var existingEntity = await DbContext
                    .GetInventoryItemsByInventoryItemNameAsync(new InventoryItem { InventoryItemName = request.InventoryItemName });

                if (existingEntity != null)
                    ModelState.AddModelError("InventoryItemName", "Inventory item name already exists: " + request.InventoryItemName);

                if (!ModelState.IsValid)
                    return BadRequest();

                // Create entity from request model
                var entity = request.ToEntity();

                // Add entity to repository
                DbContext.Add(entity);

                // Save entity in database
                await DbContext.SaveChangesAsync();

                // Set the entity to response model
                response.Model = entity;
            }
            catch (Exception ex)
            {
                response.IsError = true;
                response.ErrorMessage = "There was an internal error, please contact to technical support.";
                Logger.LogCritical("There was an error on '{0}' invocation: {1}", nameof(AddInventoryItemAsync), ex);
            }

            return response.ToHttpCreatedResponse();
        }

        // PUT
        // api/v1/ShopBridge/InventoryItem/5

        /// <summary>
        /// Updates an existing Inventory item
        /// </summary>
        /// <param name="id">Inventory item ID</param>
        /// <param name="request">Request model</param>
        /// <returns>A response as update Inventory item result</returns>      
        [HttpPut("InventoryItem/{id}")]       
        public async Task<IActionResult> UpdateInventoryItemAsync(int id, [FromBody]PutInventoryItemsRequest request)
        {
            Logger.LogDebug("'{0}' has been invoked", nameof(UpdateInventoryItemAsync));

            var response = new Response();

            try
            {
                // Get Inventory item by id
                var entity = await DbContext.GetInventoryItemsAsync(new InventoryItem(id));

                // Validate if entity exists
                if (entity == null)
                    return NotFound();

                // Set changes to entity
                entity.InventoryItemName = request.InventoryItemName;
                entity.SupplierID = request.SupplierID;
               
                entity.Price = request.Price;

                // Update entity in repository
                DbContext.Update(entity);

                // Save entity in database
                await DbContext.SaveChangesAsync();
            }
            catch (Exception ex)
            {
                response.IsError = true;
                response.ErrorMessage = "There was an internal error, please contact to technical support.";
                Logger.LogCritical("There was an error on '{0}' invocation: {1}", nameof(UpdateInventoryItemAsync), ex);
            }

            return response.ToHttpResponse();
        }

        // DELETE
        // api/v1/ShopBridge/InventoryItem/5

        /// <summary>
        /// Deletes an Inventory item
        /// </summary>
        /// <param name="id">Inventory item ID</param>
        /// <returns>A response after delete Inventory item result</returns>      
        [HttpDelete("InventoryItem/{id}")]      
        public async Task<IActionResult> DeleteInventoryItemAsync(int id)
        {
            Logger.LogDebug("'{0}' has been invoked", nameof(DeleteInventoryItemAsync));

            var response = new Response();

            try
            {
                // Get Inventory item by id
                var entity = await DbContext.GetInventoryItemsAsync(new InventoryItem(id));

                // Validate if entity exists
                if (entity == null)
                    return NotFound();

                // Remove entity from repository
                DbContext.Remove(entity);

                // Delete entity in database
                await DbContext.SaveChangesAsync();
            }
            catch (Exception ex)
            {
                response.IsError = true;
                response.ErrorMessage = "There was an internal error, please contact to technical support.";
                Logger.LogCritical("There was an error on '{0}' invocation: {1}", nameof(DeleteInventoryItemAsync), ex);
            }

            return response.ToHttpResponse();
        }
    }
}
