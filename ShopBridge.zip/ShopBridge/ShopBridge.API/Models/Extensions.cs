﻿using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace ShopBridge.API.Models
{
#pragma warning disable CS1591
    public static class InventoryDbContextExtensions
    {
        public static IQueryable<InventoryItem> GetInventoryItems(this InventoryDbContext dbContext)
        {
            // Get query from DbSet
            var query = dbContext.InventoryItems.AsQueryable();
            return query;
        }

        public static async Task<InventoryItem> GetInventoryItemsAsync(this InventoryDbContext dbContext, InventoryItem entity)
            => await dbContext.InventoryItems.FirstOrDefaultAsync(item => item.InventoryItemID == entity.InventoryItemID);

        public static async Task<InventoryItem> GetInventoryItemsByInventoryItemNameAsync(this InventoryDbContext dbContext, InventoryItem entity)
            => await dbContext.InventoryItems.FirstOrDefaultAsync(item => item.InventoryItemName == entity.InventoryItemName);
    }

   
#pragma warning restore CS1591
}
