﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace ShopBridge.API.Models
{
#pragma warning disable CS1591
    public partial class InventoryItem
    {
        public InventoryItem()
        {
        }

        public InventoryItem(int? inventoryItemID)
        {
            InventoryItemID = inventoryItemID;
        }

        public int? InventoryItemID { get; set; }
        public string InventoryItemName { get; set; }
        public int? SupplierID { get; set; }
        public string Brand { get; set; }
        public string Barcode { get; set; }
        public decimal? TaxRate { get; set; }
        public decimal? Price { get; set; }   
        public string InternalComments { get; set; }       
        public DateTime? ValidFrom { get; set; }
        public DateTime? ValidTo { get; set; }
    }

    public class InventoryItemsConfiguration : IEntityTypeConfiguration<InventoryItem>
    {
        public void Configure(EntityTypeBuilder<InventoryItem> builder)
        {
            // Set configuration for entity
            builder.ToTable("InventoryItems", "ShopBridge");

            // Set key for entity
            builder.HasKey(p => p.InventoryItemID);

            // Set configuration for columns

            builder.Property(p => p.InventoryItemName).HasColumnType("nvarchar(200)").IsRequired();
            builder.Property(p => p.SupplierID).HasColumnType("int").IsRequired();
            builder.Property(p => p.Brand).HasColumnType("nvarchar(100)");
            builder.Property(p => p.TaxRate).HasColumnType("decimal(18, 3)").IsRequired();
            builder.Property(p => p.Price).HasColumnType("decimal(18, 2)").IsRequired();
            builder.Property(p => p.InternalComments).HasColumnType("nvarchar(max)");          
           

            // Columns with default value

            builder
                .Property(p => p.InventoryItemID)
                .HasColumnType("int")
                .IsRequired()
                .HasDefaultValueSql("NEXT VALUE FOR [Sequences].[InventoryItemID]");

            // Computed columns

            // Columns with generated value on add or update

            builder
                .Property(p => p.ValidFrom)
                .HasColumnType("datetime2")
                .IsRequired()
                .ValueGeneratedOnAddOrUpdate();

            builder
                .Property(p => p.ValidTo)
                .HasColumnType("datetime2")
                .IsRequired()
                .ValueGeneratedOnAddOrUpdate();
        }
    }

    public class InventoryDbContext : DbContext
    {
        public InventoryDbContext(DbContextOptions<InventoryDbContext> options)
            : base(options)
        {
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            // Apply configurations for entity

            modelBuilder
                .ApplyConfiguration(new InventoryItemsConfiguration());

            base.OnModelCreating(modelBuilder);
        }

        public DbSet<InventoryItem> InventoryItems { get; set; }
    }
#pragma warning restore CS1591
}
