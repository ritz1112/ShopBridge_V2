﻿using System;
using System.ComponentModel.DataAnnotations;

namespace ShopBridge.API.Models
{
#pragma warning disable CS1591
    public class PostInventoryItemsRequest
    {
        [Key]
        public int? InventoryItemID { get; set; }

        [Required]
        [StringLength(200)]
        public string InventoryItemName { get; set; }

        [Required]
        public int? SupplierID { get; set; }      

        [StringLength(100)]
        public string Brand { get; set; }      

        [StringLength(100)]
        public string Barcode { get; set; }
        public decimal? Price { get; set; }
        [Required]
        public decimal? TaxRate { get; set; }     

        public string InternalComments { get; set; }      

        public DateTime? ValidFrom { get; set; }

        public DateTime? ValidTo { get; set; }
    }

    public class PutInventoryItemsRequest
    {
        [Required]
        [StringLength(200)]
        public string InventoryItemName { get; set; }

        [Required]
        public int? SupplierID { get; set; }

        public int? ColorID { get; set; }

        [Required]
        public decimal? Price { get; set; }
    }

    public static class Extensions
    {
        public static InventoryItem ToEntity(this PostInventoryItemsRequest request)
            => new InventoryItem
            {
                InventoryItemID = request.InventoryItemID,
                InventoryItemName = request.InventoryItemName,
                SupplierID = request.SupplierID,
                
                Brand = request.Brand,
               
                TaxRate = request.TaxRate,
                Price = request.Price,
               
                InternalComments = request.InternalComments,               
                
                ValidFrom = request.ValidFrom,
                ValidTo = request.ValidTo
            };
    }
}
