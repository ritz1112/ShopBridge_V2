﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ShopBridge.APITests.Controllers
{
    class InventoryControllerTests
    {
    }
}
