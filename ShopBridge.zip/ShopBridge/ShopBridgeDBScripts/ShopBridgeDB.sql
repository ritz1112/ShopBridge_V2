USE [master]
GO
/****** Object:  Database [ShopBridge]    Script Date: 04-06-2021 19:08:09 ******/
CREATE DATABASE [ShopBridge]
 CONTAINMENT = NONE
 ON  PRIMARY 
( NAME = N'ShopBridge', FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL15.SQLEXPRESS\MSSQL\DATA\ShopBridge.mdf' , SIZE = 8192KB , MAXSIZE = UNLIMITED, FILEGROWTH = 65536KB )
 LOG ON 
( NAME = N'ShopBridge_log', FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL15.SQLEXPRESS\MSSQL\DATA\ShopBridge_log.ldf' , SIZE = 8192KB , MAXSIZE = 2048GB , FILEGROWTH = 65536KB )
 WITH CATALOG_COLLATION = DATABASE_DEFAULT
GO
ALTER DATABASE [ShopBridge] SET COMPATIBILITY_LEVEL = 150
GO
IF (1 = FULLTEXTSERVICEPROPERTY('IsFullTextInstalled'))
begin
EXEC [ShopBridge].[dbo].[sp_fulltext_database] @action = 'enable'
end
GO
ALTER DATABASE [ShopBridge] SET ANSI_NULL_DEFAULT OFF 
GO
ALTER DATABASE [ShopBridge] SET ANSI_NULLS OFF 
GO
ALTER DATABASE [ShopBridge] SET ANSI_PADDING OFF 
GO
ALTER DATABASE [ShopBridge] SET ANSI_WARNINGS OFF 
GO
ALTER DATABASE [ShopBridge] SET ARITHABORT OFF 
GO
ALTER DATABASE [ShopBridge] SET AUTO_CLOSE OFF 
GO
ALTER DATABASE [ShopBridge] SET AUTO_SHRINK OFF 
GO
ALTER DATABASE [ShopBridge] SET AUTO_UPDATE_STATISTICS ON 
GO
ALTER DATABASE [ShopBridge] SET CURSOR_CLOSE_ON_COMMIT OFF 
GO
ALTER DATABASE [ShopBridge] SET CURSOR_DEFAULT  GLOBAL 
GO
ALTER DATABASE [ShopBridge] SET CONCAT_NULL_YIELDS_NULL OFF 
GO
ALTER DATABASE [ShopBridge] SET NUMERIC_ROUNDABORT OFF 
GO
ALTER DATABASE [ShopBridge] SET QUOTED_IDENTIFIER OFF 
GO
ALTER DATABASE [ShopBridge] SET RECURSIVE_TRIGGERS OFF 
GO
ALTER DATABASE [ShopBridge] SET  DISABLE_BROKER 
GO
ALTER DATABASE [ShopBridge] SET AUTO_UPDATE_STATISTICS_ASYNC OFF 
GO
ALTER DATABASE [ShopBridge] SET DATE_CORRELATION_OPTIMIZATION OFF 
GO
ALTER DATABASE [ShopBridge] SET TRUSTWORTHY OFF 
GO
ALTER DATABASE [ShopBridge] SET ALLOW_SNAPSHOT_ISOLATION OFF 
GO
ALTER DATABASE [ShopBridge] SET PARAMETERIZATION SIMPLE 
GO
ALTER DATABASE [ShopBridge] SET READ_COMMITTED_SNAPSHOT OFF 
GO
ALTER DATABASE [ShopBridge] SET HONOR_BROKER_PRIORITY OFF 
GO
ALTER DATABASE [ShopBridge] SET RECOVERY SIMPLE 
GO
ALTER DATABASE [ShopBridge] SET  MULTI_USER 
GO
ALTER DATABASE [ShopBridge] SET PAGE_VERIFY CHECKSUM  
GO
ALTER DATABASE [ShopBridge] SET DB_CHAINING OFF 
GO
ALTER DATABASE [ShopBridge] SET FILESTREAM( NON_TRANSACTED_ACCESS = OFF ) 
GO
ALTER DATABASE [ShopBridge] SET TARGET_RECOVERY_TIME = 60 SECONDS 
GO
ALTER DATABASE [ShopBridge] SET DELAYED_DURABILITY = DISABLED 
GO
ALTER DATABASE [ShopBridge] SET ACCELERATED_DATABASE_RECOVERY = OFF  
GO
ALTER DATABASE [ShopBridge] SET QUERY_STORE = OFF
GO
USE [ShopBridge]
GO
/****** Object:  Table [dbo].[Inventory]    Script Date: 04-06-2021 19:08:10 ******/

/****** Object:  Table [dbo].[InventoryItem]    Script Date: 04-06-2021 19:08:10 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[InventoryItem](
	[InventoryItemID] [int] NOT NULL,
	[InventoryItemName] [nvarchar](200) NOT NULL,
	[SupplierID] [int] NOT NULL,
	[Brand] [nvarchar](100) NOT NULL,
	[TaxRate] [decimal](18, 3) NOT NULL,
	[Price] [decimal](18, 2) NOT NULL,
	[InternalComments] [nvarchar](max) NOT NULL,
	[ValidFrom] [datetime] NOT NULL,
	[ValidTo] [datetime] NOT NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  StoredProcedure [dbo].[sp_AddInventory]    Script Date: 04-06-2021 19:08:10 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[sp_AddInventory]
    -- Add the parameters for the stored procedure here
    (@Name nvarchar(50),
     @Description nvarchar(max) =  NULL,
     @Price decimal(18,0)  =  NULL,
     @Quantity int  =  NULL)
AS
BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with SELECT statements.
    SET NOCOUNT ON;

INSERT INTO [dbo].[Inventory]
           ([Name]
           ,[Description]
           ,[Price]
           ,[Quantity])
     VALUES
           (@Name,
            @Description,
            @Price,
            @Quantity)

SELECT SCOPE_IDENTITY() AS ID

END

GO
/****** Object:  StoredProcedure [dbo].[sp_DeleteInventory]    Script Date: 04-06-2021 19:08:10 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[sp_DeleteInventory]
    -- Add the parameters for the stored procedure here
    @ID int
AS
BEGIN
    SET NOCOUNT ON;

DELETE FROM [dbo].[Inventory]
      WHERE ID = @ID
END


GO
/****** Object:  StoredProcedure [dbo].[sp_GetInventory]    Script Date: 04-06-2021 19:08:10 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[sp_GetInventory]
    -- Add the parameters for the stored procedure here
    @ID int = NULL
AS
BEGIN
    SET NOCOUNT ON;
SELECT [ID]
      ,[Name]
      ,[Description]
      ,[Price]
      ,[Quantity]
  FROM [ShopBridge].[dbo].[Inventory] Where ID = ISnull(@ID,ID)

 END
GO
/****** Object:  StoredProcedure [dbo].[sp_UpdateInventory]    Script Date: 04-06-2021 19:08:10 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[sp_UpdateInventory]
    -- Add the parameters for the stored procedure here
    (@ID int, @Name nvarchar(50),
     @Description nvarchar(max) =  NULL,
     @Price decimal(18,0)  =  NULL,
     @Quantity int  =  NULL)
AS
BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with SELECT statements.
    SET NOCOUNT ON;

UPDATE [dbo].[Inventory]
   SET [Name] = @Name,
       [Description] = @Description,
       [Price] = @Price,
       [Quantity] = @Quantity
 WHERE Id = @ID
END


GO
USE [master]
GO
ALTER DATABASE [ShopBridge] SET  READ_WRITE 
GO
